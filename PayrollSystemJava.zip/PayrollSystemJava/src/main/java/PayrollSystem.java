import java.awt.Color;
import java.awt.Font;
import javax.swing.*;

public class PayrollSystem extends JFrame {

    // ---- Formulas (from the whiteboard) ----
    private static final double REGULAR_HOURS = 40;    // hours before overtime starts (assumed)
    private static final double OT_MULTIPLIER = 1.25;  // OT pay = OT hours * rate * 1.25
    private static final double PAGIBIG_RATE = 0.02;   // Pag-ibig = Basic Pay * 2%
    private static final double MEDICAL_RATE = 0.02;   // Medical  = Basic Pay * 2%
    private static final double SSS_RATE = 0.045;      // SSS not on the whiteboard (assumed 4.5% of Basic Pay)

    private JTextField txtEmpNo, txtLast, txtFirst, txtMI, txtHours, txtRate;
    private JTextField txtMedical, txtSSS, txtWTax, txtPagibig;
    private JTextField txtDeduction, txtBasic, txtOT, txtNet;
    private JComboBox<String> cboDept;

    public PayrollSystem() {
        setTitle("Payroll System");
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setSize(780, 620);
        setLocationRelativeTo(null);
        setLayout(null);

        Font labelFont = new Font("Tahoma", Font.BOLD | Font.ITALIC, 13);

        JLabel title = new JLabel("PAYROLL SYSTEM");
        title.setFont(new Font("Times New Roman", Font.BOLD | Font.ITALIC, 24));
        title.setForeground(new Color(220, 20, 120));
        title.setBounds(270, 15, 300, 35);
        add(title);

        // ----- Employee info -----
        addLabel("Employee Number", 40, 80, 130, labelFont);
        txtEmpNo = addField(220, 78, 230);

        addLabel("Last Name", 40, 125, 90, labelFont);
        txtLast = addField(130, 123, 110);

        addLabel("First Name", 270, 125, 90, labelFont);
        txtFirst = addField(360, 123, 100);

        addLabel("MI", 500, 125, 30, labelFont);
        txtMI = addField(530, 123, 30);

        addLabel("Department", 40, 175, 100, labelFont);
        cboDept = new JComboBox<>(new String[]{"Accounting", "Marketing", "Admin", "Faculty"});
        cboDept.setBounds(160, 173, 140, 25);
        add(cboDept);

        // ----- Hours and rate -----
        addLabel("No. of hours work", 40, 225, 140, labelFont);
        txtHours = addField(190, 223, 70);

        addLabel("Rate/Hr", 300, 225, 70, labelFont);
        txtRate = addField(375, 223, 100);

        // ----- Left column (contributions) -----
        addLabel("Medical:", 40, 290, 80, labelFont);
        txtMedical = addField(140, 288, 90);

        addLabel("SSS:", 40, 330, 80, labelFont);
        txtSSS = addField(140, 328, 90);

        addLabel("W/Tax:", 40, 370, 80, labelFont);
        txtWTax = addField(140, 368, 90);

        addLabel("Pag-ibig:", 40, 410, 80, labelFont);
        txtPagibig = addField(140, 408, 90);

        // ----- Right column (pay) -----
        addLabel("Deduction:", 330, 290, 90, labelFont);
        txtDeduction = addField(440, 288, 100);

        addLabel("Basic Pay:", 330, 330, 90, labelFont);
        txtBasic = addField(440, 328, 100);

        addLabel("OT Pay:", 330, 370, 90, labelFont);
        txtOT = addField(440, 368, 100);

        addLabel("Net Pay:", 330, 410, 90, labelFont);
        txtNet = addField(440, 408, 100);

        for (JTextField f : new JTextField[]{txtMedical, txtSSS, txtWTax, txtPagibig,
                txtDeduction, txtBasic, txtOT, txtNet}) {
            f.setEditable(false);
        }

        // ----- Buttons -----
        JButton btnCompute = new JButton("COMPUTE");
        btnCompute.setBounds(170, 500, 110, 30);
        btnCompute.addActionListener(e -> compute());
        add(btnCompute);

        JButton btnClear = new JButton("CLEAR");
        btnClear.setBounds(400, 500, 110, 30);
        btnClear.addActionListener(e -> clear());
        add(btnClear);
    }

    private void addLabel(String text, int x, int y, int w, Font f) {
        JLabel l = new JLabel(text);
        l.setFont(f);
        l.setBounds(x, y, w, 20);
        add(l);
    }

    private JTextField addField(int x, int y, int w) {
        JTextField t = new JTextField();
        t.setBounds(x, y, w, 24);
        add(t);
        return t;
    }

    private void compute() {
        double hours, rate;
        try {
            hours = Double.parseDouble(txtHours.getText().trim());
            rate = Double.parseDouble(txtRate.getText().trim());
            if (hours < 0 || rate < 0) throw new NumberFormatException();
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this,
                    "Please enter valid positive numbers for hours and rate.",
                    "Invalid Input", JOptionPane.ERROR_MESSAGE);
            return;
        }

        double regularHours = Math.min(hours, REGULAR_HOURS);
        double otHours = Math.max(0, hours - REGULAR_HOURS);

        double basicPay = regularHours * rate;
        double otPay = otHours * rate * OT_MULTIPLIER;

        double wTax = basicPay * taxRate((String) cboDept.getSelectedItem());
        double pagibig = basicPay * PAGIBIG_RATE;
        double medical = basicPay * MEDICAL_RATE;
        double sss = basicPay * SSS_RATE;

        double totalDeduction = sss + wTax + pagibig + medical;
        double netPay = basicPay - totalDeduction + otPay;

        txtBasic.setText(fmt(basicPay));
        txtOT.setText(fmt(otPay));
        txtSSS.setText(fmt(sss));
        txtMedical.setText(fmt(medical));
        txtPagibig.setText(fmt(pagibig));
        txtWTax.setText(fmt(wTax));
        txtDeduction.setText(fmt(totalDeduction));
        txtNet.setText(fmt(netPay));
    }

    // W/Tax rate depends on the department
    // Modify if there's a list of department assigned by our prof
    private double taxRate(String dept) {
        switch (dept) {
            case "Accounting": return 0.05;
            case "Marketing":  return 0.025;
            case "Admin":      return 0.03;
            case "Faculty":    return 0.04;
            default:           return 0;
        }
    }

    private String fmt(double v) {
        return String.format("%.2f", v);
    }

    private void clear() {
        for (JTextField f : new JTextField[]{txtEmpNo, txtLast, txtFirst, txtMI, txtHours, txtRate,
                txtMedical, txtSSS, txtWTax, txtPagibig, txtDeduction, txtBasic, txtOT, txtNet}) {
            f.setText("");
        }
        cboDept.setSelectedIndex(0);
        txtEmpNo.requestFocus();
    }

}
